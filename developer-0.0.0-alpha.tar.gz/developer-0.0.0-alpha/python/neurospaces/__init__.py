"""!
This is the top level module for g3. All python interfaces
to GENESIS 3 share this parent.
"""


__author__ = 'Mando Rodriguez'
__credits__ = []
__license__ = "GPL"
__version__ = "0.1"
__status__ = "Development"

